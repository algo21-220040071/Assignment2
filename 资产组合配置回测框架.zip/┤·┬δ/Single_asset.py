# -*- coding: utf-8 -*-
"""
@author: Liran CHEN 220040071
"""
import pandas as pd
import numpy as np



class Single:
    def __init__(self, ann, single, rf, input_path, file, output_path,
                 single_file):
        self.ann = ann
        self.single = single
        self.rf = rf
        self.input_path = input_path
        self.file = file
        self.output_path = output_path
        self.single_file = single_file
    
    #读取excel
    def sheet_read(self):    
        data = pd.read_excel(self.input_path+self.file, sheet_name = '数据',
                             index_col = 0)
        return data
    
    #计算标的总收益
    def wholeR(self, data):
        p = data[self.single]
        wr = (p.iloc[-1]-p.iloc[0])/p.iloc[0]
        return wr
    
    #计算日收益率    
    def dailyR(self, data):    
        daily = data[self.single].diff()/data[self.single].shift(1)
        #对数收益率
        #daily = np.log(data['沪深300']/data['沪深300'].shift(1))
        return daily
    
    #计算年化收益率
    def annualR(self, data, gb, period):
        """period = 'by year' or 'all period' """
        if period == 'by year':
            r_p = gb[self.single].apply(lambda x:(x.iloc[-1]-x.iloc[0])/x.iloc[0])
        elif period == 'all period':
            r = self.wholeR(data)
            r_p = ((1+r)**(self.ann/data['daily'].count())-1)
        return r_p
    
    #计算年化波动率
    def annualV(self, data, gb, period):
        """period = 'by year' or 'all period' """
        if period == 'by year':
            s = gb['daily'].apply(np.nanstd)
            V = np.sqrt(self.ann)*s
        elif period == 'all period':
            s = np.nansum((data['daily'].diff())**2)
            V = np.sqrt(self.ann*s/(data['daily'].count()-1))
        return V
    
    #计算历史最大回撤，回撤发生时间和结束时间
    def max_dd(self, returns):
        #计算每天的累计收益
        r = (returns+1).cumprod()
        #r.cummax()计算出累计收益的最大值，再用每天的累计收益除以这个最大值，算出收益率
        dd = r.div(r.cummax()).sub(1)
        #取最小
        mdd = dd.min()
        end = dd.idxmin()
        end = end.date()
        start = r.loc[:end].idxmax()
        start = start.date()
        return -mdd, start, end
    
    #计算夏普比率
    def sharpe(self, data, gb, period):
        """period = 'by year' or 'all period' """
        r_p = self.annualR(data, gb, period)
        V = self.annualV(data, gb, period)
        sharpe =(r_p - self.rf)/V
        if period == 'by year':
            sharpe = pd.DataFrame(sharpe, columns=['夏普比率'])
        return sharpe
    
    #计算卡玛比率
    def carmar(self, data, gb, period):
        """period = 'by year' or 'all period' """
        r_p = self.annualR(data, gb, period)
        if period == 'by year':
            mdd, start, end = zip(*gb['daily'].apply(self.max_dd))
            carmar = r_p/mdd
            carmar = pd.DataFrame(carmar)
            carmar.rename(columns={self.single:'carmar比率'},inplace = True)
        elif period == 'all period':
            mdd, start, end = self.max_dd(data['daily'])
            carmar = r_p/mdd
        return carmar
    
    
    def data_process(self):
        data = self.sheet_read()
        #data.rename(columns={'Unnamed: 0':'日期'},inplace = True)
        data['daily'] = self.dailyR(data)
        #data.index = data['日期']
        
        years = data.index.year
        years = pd.DataFrame(years)
        years.index = data.index
        data['years'] = data.index.year
        
        return data
    
        #输出策略分年度、整体表现，绘制净值图          
    def output(self, df_year, df_all):

        writer = pd.ExcelWriter(self.output_path + self.single_file,
                                engine='xlsxwriter')
        df_year.to_excel(writer, sheet_name = '单一资产分年度表现')
        df_all.to_excel(writer, sheet_name = '单一资产整体表现')
        writer.save()
    
    def single_backtest(self):
        #清洗数据，并groupby
        data = self.data_process()
        gb = data.groupby('years')
        
        #计算分年度的表现
        year_annualR = self.annualR(data, gb, 'by year')
        year_annualR = year_annualR.apply(lambda x: '%.2f%%' % (x*100))
        year_annualR = pd.DataFrame(year_annualR)
        year_annualR.rename(columns={self.single:'年化收益率'},inplace = True)
        
        year_annualV = self.annualV(data, gb, 'by year')
        year_annualV = year_annualV.apply(lambda x: '%.2f%%' % (x*100))
        year_annualV = pd.DataFrame(year_annualV)
        year_annualV.rename(columns={'daily':'年化波动率'},inplace = True)
        
        year_md, year_start, year_end = zip(*gb['daily'].apply(self.max_dd))
        year_md = pd.DataFrame(year_md, index = year_annualR.index,
                               columns = ['最大回撤'])
        year_md = year_md.applymap(lambda x: '%.2f%%' % (x*100))
        year_start = pd.DataFrame(year_start, index = year_annualR.index,
                                  columns = ['最大回撤开始时间'])
        year_end = pd.DataFrame(year_end, index = year_annualR.index,
                                columns = ['最大回撤结束时间'])
        
        year_sharpe = round(self.sharpe(data, gb, 'by year'),2)
        year_carmar = round(self.carmar(data, gb, 'by year'),2)
        
        df_year = pd.concat([year_annualR, year_annualV, year_md, year_start, 
                             year_end, year_sharpe, year_carmar], axis = 1)
        

        #计算整体表现
        all_wholeR = self.wholeR(data)
        all_wholeR = "%.2f%%" % (all_wholeR * 100)
        all_annualR = self.annualR(data, gb, 'all period')
        all_annualR = "%.2f%%" % (all_annualR * 100)
        all_annualV = self.annualV(data, gb, 'all period')
        all_annualV = "%.2f%%" % (all_annualV * 100)
        
        all_md, all_start, all_end = self.max_dd(data['daily'])
        all_md = "%.2f%%" % (all_md * 100)
        
        all_sharpe = self.sharpe(data, gb, 'all period')
        all_carmar = self.carmar(data, gb, 'all period')
        df_all = pd.DataFrame({'标的总收益' : [all_wholeR], '年化收益率' : 
                               [all_annualR], '年化波动率' : [all_annualV], 
                               '最大回撤' : [all_md], '最大回撤起始时间' : 
                               [all_start], '最大回撤结束时间': [all_end], 
                               '夏普比率' : [all_sharpe], 'carmar比率' : 
                               [all_carmar]})
        df_all.index = ['整体表现']

        self.output(df_year, df_all)



